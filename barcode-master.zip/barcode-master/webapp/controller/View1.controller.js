sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("beep.BeepTest.controller.View1", {
		onInit: function () {

		},

		OnClear: function () {
			this.byId("inputId").setValue();
		},

		// When you click on submit button then this function will fire…….
		onButtonPress: function () {
			// var inputValue = this.byId("inputId").getValue();
			// if (inputValue === null || inputValue === undefined || inputValue === "") {
			// 	sap.m.MessageToast.show("Enter order id");
			// 	return;
			// }
			var audio = new Audio("sounds/beep-01a.mp3");
		//	audio.oncanplaythrough = function () {
				audio.play();
		//	}
			this.byId("inputId").setValue();

		}

	});
});